"""Portable Word export regressions; run with a Python containing python-docx."""
import argparse
import hashlib
import json
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as ET

from docx import Document

SCRIPT = Path(__file__).resolve().parents[1] / "ax-bizplan-coach-v05/scripts/build_docx.py"
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
KEEP = None


def diagram(path):
    def chunk(name, data):
        return struct.pack(">I",len(data)) + name + data + struct.pack(">I",zlib.crc32(name+data))
    w,h = 320,70
    row = b"\xff\xff\xff"*20 + b"\x33\x66\x77"*100 + b"\xc6\xd2\xd9"*80 + b"\x33\x66\x77"*100 + b"\xff\xff\xff"*20
    raw = b"".join(b"\0"+(row if 16<y<54 else b"\xff\xff\xff"*w) for y in range(h))
    path.write_bytes(b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",w,h,8,2,0,0,0))+chunk(b"IDAT",zlib.compress(raw))+chunk(b"IEND",b""))


class ExportTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.base = Path(KEEP or temp.name)
        self.base.mkdir(parents=True, exist_ok=True)
        self.md = self.base/"test.md"
        self.out = self.base/"보완 계획.docx"
        diagram(self.base/"diagram.png")
        rows = "".join(f"| 단계 {i:03} | 현장 생산수량·시각을 원장과 대조하고 작업자 검수를 기록함 | 담당자 |\n" for i in range(76))
        self.md.write_text("# 1. 장비 연결\n\n## 설치 순서\n![계측 연결 개념도](diagram.png)\n\n# 2. 비용 점검\n| 순번 | 검증 내용 | 역할 |\n|---|---|---|\n"+rows)
        self.template=self.base/"공식양식_예시.docx"
        d=Document()
        d.add_heading("신청서 관리번호", level=1)
        d.add_paragraph("{{OVERVIEW}}")
        cell=d.add_table(rows=1,cols=1).cell(0,0)
        cell.text="{{CHECK}}"
        d.add_paragraph("대표자 서명란                              (인)")
        d.save(self.template)
        self.mapping=self.base/"map.json"
        self.form={"template_sha256":hashlib.sha256(self.template.read_bytes()).hexdigest(),
                   "fields":{"{{OVERVIEW}}":"1. 장비 연결","{{CHECK}}":"2. 비용 점검"}}

    def call(self,*extra):
        return subprocess.run([sys.executable,str(SCRIPT),str(self.md),str(self.out),
            "--date","2026-11-19","--version","v3","--title","설비 계측 계획","--mode","submission",
            *map(str,extra)],cwd=self.base.parent,capture_output=True,text=True)

    def test_standalone(self):
        result=self.call()
        self.assertEqual(result.returncode,0,result.stderr)
        d=Document(self.out)
        self.assertEqual(len(d.inline_shapes),1)
        self.assertEqual([p.style.name for p in d.paragraphs if p.style.name.startswith("Heading")],["Heading 1","Heading 2","Heading 1"])
        self.assertIn("공고 원본 양식 미적용"," ".join(p.text for p in d.paragraphs))
        self.assertEqual(len(d.tables[0].rows),77)
        widths=[col.width for col in d.tables[0].columns]
        self.assertGreater(widths[1],widths[0])
        with ZipFile(self.out) as z:
            root=ET.fromstring(z.read("word/document.xml"))
            self.assertEqual(len(root.xpath("//w:tblHeader",namespaces=NS)),1)
            self.assertEqual(len(root.xpath("//w:cantSplit",namespaces=NS)),77)
            self.assertIn(b" PAGE ",z.read("word/footer1.xml"))
            self.assertIn("Noto Sans KR",z.read("word/document.xml").decode())
        if KEEP: (self.base/"standalone.docx").write_bytes(self.out.read_bytes())

    def test_adjacent_tables_keep_separate_headers(self):
        self.md.write_text("| 설비 | 담당 |\n|---|---|\n| A | 김 |\n\n| 시험 | 상태 |\n|---|---|\n| B | 대기 |")
        result = self.call()
        self.assertEqual(result.returncode, 0, result.stderr)
        with ZipFile(self.out) as bundle:
            xml = ET.fromstring(bundle.read("word/document.xml"))
        self.assertEqual(len(xml.xpath("//w:tbl", namespaces=NS)), 2)
        self.assertEqual(len(xml.xpath("//w:tbl/following-sibling::*[1][self::w:tbl]", namespaces=NS)), 0)

    def test_form_and_errors(self):
        self.mapping.write_text(json.dumps(self.form))
        args=("--template",self.template,"--field-map",self.mapping)
        result=self.call(*args)
        self.assertEqual(result.returncode,0,result.stderr)
        good=self.out.read_bytes()
        with ZipFile(self.out) as z:
            root=ET.fromstring(z.read("word/document.xml"))
            text="".join(root.xpath("//w:t/text()",namespaces=NS))
            for mark in ["신청서 관리번호","대표자 서명란","단계 075","계측 연결 개념도"]:
                self.assertIn(mark,text)
            self.assertNotIn("{{",text)
            self.assertEqual(len(root.xpath("//w:tc/w:tbl",namespaces=NS)),1)
        if KEEP: (self.base/"mapped.docx").write_bytes(good)
        bads=[{**self.form,"fields":{"{{OVERVIEW}}":"1. 장비 연결"}},
              {**self.form,"template_sha256":"0"*64},
              {**self.form,"fields":{"{{OVERVIEW}}":"$body","{{CHECK}}":"2. 비용 점검"}}]
        for bad in bads:
            self.mapping.write_text(json.dumps(bad))
            self.assertNotEqual(self.call(*args).returncode,0)
            self.assertEqual(self.out.read_bytes(),good)
        self.mapping.write_text(json.dumps(self.form))
        self.md.write_text(self.md.read_text()+"\n# 3. 누락 절\n현장 기록")
        self.assertNotEqual(self.call(*args).returncode,0)
        self.assertEqual(self.out.read_bytes(),good)


if __name__=="__main__":
    arg=argparse.ArgumentParser(add_help=False)
    arg.add_argument("--keep-fixture")
    opts,other=arg.parse_known_args()
    KEEP=opts.keep_fixture
    unittest.main(argv=[sys.argv[0]]+other)
