"""Exercise release acceptance examples without opening any D-company author files."""
import csv
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

QA = Path(__file__).resolve().parent
SKILL = QA.parent / "ax-bizplan-coach-v05"
EDGE = QA / "경계사례"


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))


class ReleaseEdges(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.work = Path(temp.name)

    def cli(self, script, *args):
        return subprocess.run(
            [sys.executable, str(SKILL / "scripts" / script), *map(str, args)],
            cwd=self.work, capture_output=True, text=True, check=True,
        )

    def calculate(self, spec):
        spec_file = self.work / "spec.json"
        spec_file.write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")
        csv_file = self.work / "rows.csv"
        # Same dimensions as the acceptance question, independent, newly generated rows.
        with csv_file.open("w", encoding="utf-8", newline="") as dest:
            writer = csv.writer(dest)
            writer.writerow(["lot", "period", "units", "defects", "kwh", "kW", "hours"])
            for i in range(6):
                writer.writerow([f"QA-{i+1}", f"M{1+i//2}", 500000, 25000, 15000, 150, 100])
        out, html = self.work / "result.json", self.work / "trace.html"
        self.cli("check_case.py", "--spec", spec_file, "--csv", csv_file, "--out", out, "--html", html)
        return json.loads(out.read_text()), html.read_text()

    def test_six_lots_conflict_source_and_monthly_feasibility(self):
        spec = json.loads((SKILL / "assets/neutral-case.json").read_text())
        spec["columns"] = dict(lot="lot", period="period", units="units", defects="defects",
                               kwh="kwh", power_kw="kW", hours="hours")
        circuit = spec["energy"]["boundary"]
        a = dict(value=0.020, source="QA-대표-2", boundary=circuit)
        b = dict(value=0.025, source="QA-초기표-5", boundary="whole site")
        spec["targets"]["energy_intensity"] = [a, b]
        result, html = self.calculate(spec)
        self.assertEqual(result["metrics"]["defect_rate"]["value"], 0.05)
        self.assertEqual(result["metrics"]["defect_rate"]["rows"], list(range(2, 8)))
        self.assertEqual(result["metrics"]["energy_intensity"]["value"], 0.030)
        self.assertEqual((result["label_diagnostic"]["positive_lots"],
                          result["label_diagnostic"]["negative_lots"]), (6, 0))
        self.assertIsNone(result["label_diagnostic"]["verified_model_f1"])
        conflict = result["targets"]["energy_intensity"]
        self.assertEqual((conflict["status"], conflict["value"]), ("conflict", None))
        self.assertEqual({candidate["source"] for candidate in conflict["candidates"]},
                         {"QA-대표-2", "QA-초기표-5"})
        self.assertIn('href="#rows"', html)
        self.assertIn('href="#energy_intensity-target-1"', html)
        self.assertIn('id="energy_intensity-target-1"', html)
        self.assertIn("합산 정격(kW) × 등가가동시간(h)", html)
        self.assertIn("합산 정격 kW", html)
        for row in result["trace"]["source_rows"]:
            self.assertEqual((row["power_kw"], row["hours"], row["kwh"]), (150, 100, 15000))
        self.assertIn("QA-대표-2", html)
        spec["approvals"] = {"energy_intensity": {"source": a["source"], "by": "가상 대표",
                             "date": "2026-11-19", "basis": "QA-합성결정"}}
        result, _ = self.calculate(spec)
        self.assertEqual(result["targets"]["energy_intensity"]["value"], 0.020)
        feasibility = result["energy_feasibility"]
        self.assertEqual(feasibility["required_reduction_kwh_per_period"], 10000)
        self.assertIsNone(feasibility["recoverable_kwh_per_period"])
        self.assertEqual(feasibility["status"], "conditional")

    def test_forms_keep_eight_unreceived_requests_through_text_revision(self):
        evidence = read_csv(EDGE / "증빙대장.csv")
        self.assertEqual({r["요청ID"] for r in evidence}, {f"E{i:02}" for i in range(1, 9)})
        for row in evidence:
            for key in ("제공책임자", "판단용도", "기한또는판단시점"):
                self.assertTrue(row[key].strip())
            self.assertEqual(row["상태"], "미요청")
            self.assertEqual(row["수신자료ID_위치"], "")
        form = read_csv(EDGE / "서식대조.csv")
        self.assertEqual([r["잠정장"] for r in form], [*map(str,range(1, 11)), "부속"])
        self.assertTrue(all(r["연도_회차_유형"] == "미확인" and
                            not r["공식양식_버전"] and r["증빙상태"] == "미확인" for r in form))
        roles = (EDGE / "입력과판정.md").read_text()
        for phrase in ("ERP·MES 연계 항목은 미사용", "사업교육 수료 미확인",
                       "E03·E04 모두 미요청·미수신", "현장 시운전", "실제 외부 요청·수신·승인은 0건"):
            self.assertIn(phrase, roles)

    def test_procurement_delays_learning_testing_and_acceptance_but_not_parallel_work(self):
        tasks = [
            ("order", [], 3), ("fit", ["order"], 1), ("sample", ["fit"], 2),
            ("learn", ["sample"], 1), ("test", ["learn"], 1),
            ("accept", ["test"], 1), ("education", [], 2),
        ]
        schedule = {"tasks": [dict(id=k, after=pre, duration=days) for k, pre, days in tasks],
                    "delay": {"order": 4}}
        p = self.work / "schedule.json"
        p.write_text(json.dumps(schedule))
        result = json.loads(self.cli("check_delivery.py", "delay", p).stdout)
        self.assertEqual(result["project_shift"], 4)
        for job in ("fit", "sample", "learn", "test", "accept"):
            self.assertEqual(result["tasks"][job]["shift"], 4)
        self.assertEqual(result["tasks"]["education"]["shift"], 0)

    def test_one_goal_updates_title_chart_table_and_acceptance(self):
        template = self.work / "page.md"
        template.write_text("# 지표 {{goal}}\n\n| 목표 | {{goal}} |\n\n대시보드 {{goal}}\n\n인수 계획 {{goal}}\n")
        definitions = self.work / "values.json"
        output = self.work / "plan.md"
        for value in ("0.017", "0.014"):
            definitions.write_text(json.dumps({"goal": dict(value=value, status="합성 목표",
                source="QA-목표-2", scope="시험회로 kWh/개", period="시험기간", owner="가상 승인자")}))
            self.cli("materialize.py", template, definitions, output, "--no-appendix")
            self.assertEqual(output.read_text().count(value), 4)
        self.assertNotIn("0.017", output.read_text())


if __name__ == "__main__":
    unittest.main(verbosity=2)
