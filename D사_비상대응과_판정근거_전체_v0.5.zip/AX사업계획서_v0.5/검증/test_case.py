"""Run with python3 test_case.py; no network or third-party imports."""
import csv
from decimal import Decimal
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1] / "ax-bizplan-coach-v05"
SCRIPT = ROOT / "scripts/check_case.py"
mod = importlib.util.spec_from_file_location("check_case", SCRIPT)
case = importlib.util.module_from_spec(mod)
mod.loader.exec_module(case)


class CaseRegression(unittest.TestCase):
    def setUp(self):
        self.spec = json.loads((ROOT / "assets/neutral-case.json").read_text(encoding="utf-8"), parse_float=Decimal)
        self.raw = (ROOT / "assets/neutral-lots.csv").read_bytes()

    def run_case(self):
        return case.evaluate(self.spec, self.raw)

    def test_trace_and_weighted_aggregation(self):
        r = self.run_case()
        self.assertEqual(r["metrics"]["defect_rate"]["value"], Decimal("0.02"))
        self.assertEqual(r["metrics"]["defect_rate"]["rows"], [2,3,4,5])
        self.assertEqual(r["aggregates"]["all"]["units"], 4000)
        self.assertEqual(r["label_diagnostic"]["negative_lots"], 1)
        self.assertIsNone(r["label_diagnostic"]["verified_model_f1"])

    def test_single_class_trivial_f1(self):
        self.raw = self.raw.replace(b"P02,1200,0,", b"P02,1200,1,")
        r = self.run_case()["label_diagnostic"]
        self.assertEqual((r["positive_lots"],r["negative_lots"],r["always_alert_f1_on_input"]),(4,0,1))
        self.assertIsNone(r["verified_model_f1"])

    def test_zero_production_not_an_inspected_negative(self):
        self.raw += b"S3,P05,0,0,6,6,1\n"
        r = self.run_case()
        self.assertEqual(r["aggregates"]["all"]["kwh"],606)
        self.assertIsNone(r["aggregates"]["periods"]["S3"]["energy_intensity"])
        self.assertEqual(r["label_diagnostic"]["excluded_zero_production_lots"],1)
        self.assertEqual(r["label_diagnostic"]["negative_lots"],1)

    def test_duplicate_and_overreported_counts_rejected(self):
        good = self.raw
        for bad in (good+good.splitlines(keepends=True)[-1], good.replace(b"P01,800,20",b"P01,800,801")):
            with self.subTest(raw=bad):
                self.raw = bad
                with self.assertRaises(case.CaseError):
                    self.run_case()

    def test_estimate_does_not_become_measured_when_mismatch(self):
        self.raw = self.raw.replace(b"P01,800,20,120",b"P01,800,20,119")
        with self.assertRaisesRegex(case.CaseError,"정격"):
            self.run_case()

    def test_conflict_blocks_until_specific_approval(self):
        goals = self.spec["targets"]["energy_intensity"]
        goals.append(dict(value=Decimal("0.11"),source="B:7",boundary="press circuit"))
        r = self.run_case()
        self.assertEqual(r["targets"]["energy_intensity"]["status"],"conflict")
        self.assertIsNone(r["benefits"]["scenarios"][0]["combined_gross_won"])
        self.spec["approvals"]={"energy_intensity":{"source":"B:7","by":"owner","date":"2026-01-01","basis":"EDU-01"}}
        r = self.run_case()
        self.assertEqual(r["targets"]["energy_intensity"]["value"],Decimal("0.11"))
        self.assertEqual(len(r["targets"]["energy_intensity"]["candidates"]),2)
        goals[1]["boundary"] = "entire plant"
        self.assertEqual(self.run_case()["targets"]["energy_intensity"]["status"],"boundary_mismatch")

    def test_trace_html_exposes_only_escaped_values(self):
        self.raw=self.raw.replace(b"P01",b"<script>test</script>")
        html=case.render_html(self.run_case())
        self.assertIn('href="#rows"', html)
        self.assertIn('href="#energy_intensity-target-1"', html)
        self.assertIn('id="energy_intensity-target-1"', html)
        self.assertIn('&lt;script&gt;test&lt;/script&gt;',html)
        self.assertNotIn('<script>',html)

    def test_labor_and_shared_quantity_reconcile(self):
        r=self.run_case()["budget"]
        self.assertIsNone(r["known_subtotal_won"])
        self.assertIsNone(r["expenditure_total_won"])
        e=self.spec["expenditure"]
        e["lines"][0].update(unit_won=200000,vat_won=40000,source="QUOTE-1",evidence_kind="quote")
        e["lines"][1].update(monthly_won=600000,months=2,fraction=Decimal("0.5"),source="P-1",evidence_kind="payroll")
        r=self.run_case()["budget"]
        self.assertEqual(r["expenditure_total_won"],1000000)
        self.assertTrue(r["matches_funding"])
        e["quantities"]["circuit-meter"] = 3
        r=self.run_case()["budget"]
        self.assertEqual(r["lines"][0]["net_won"],600000)
        self.assertEqual(r["expenditure_total_won"],1200000)
        self.assertFalse(r["matches_funding"])
        e["tax_basis"]="gross"
        self.assertEqual(self.run_case()["budget"]["expenditure_total_won"],1240000)
        e["lines"][0]["unit_won"]=None
        self.assertEqual(self.run_case()["budget"]["known_subtotal_won"],600000)
        self.assertIsNone(self.run_case()["budget"]["expenditure_total_won"])

    def test_benefits_withhold_sums_when_overlap_or_unknown(self):
        r=self.run_case()["benefits"]["scenarios"][-1]
        self.assertEqual(r["combined_gross_won"],Decimal("9100"))
        self.assertIsNone(r["net_after_added_opex_won"])
        self.spec["benefits"]["added_opex_per_period_won"]=1000
        self.assertEqual(self.run_case()["benefits"]["scenarios"][-1]["net_after_added_opex_won"],8100)
        for value in (False,None):
            self.spec["benefits"]["excludes_energy"]=value
            r=self.run_case()["benefits"]["scenarios"][-1]
            self.assertIsNone(r["combined_gross_won"])
            self.assertEqual(r["avoided_energy_won"],7500)

    def test_a_matching_measured_loss_is_not_a_realized_benefit(self):
        self.spec["energy"]["action"]={"idle_kw":10,"idle_hours_per_period":12,"recoverable_fraction":Decimal("0.5"),"boundary":"press circuit","measured_source":"LOG-01"}
        r=self.run_case()["energy_feasibility"]
        self.assertEqual(r["required_reduction_kwh_per_period"],60)
        self.assertEqual(r["status"],"conditional")
        self.spec["energy"]["kind"]="measured"
        self.assertEqual(self.run_case()["energy_feasibility"]["status"],"arithmetically_supported_plan")
        self.spec["energy"]["action"]["idle_kw"]=1
        self.assertEqual(self.run_case()["energy_feasibility"]["status"],"insufficient_measured_loss")
        self.spec["energy"]["action"]["boundary"]="other"
        self.assertIsNone(self.run_case()["energy_feasibility"]["recoverable_kwh_per_period"])

    def test_per_row_boundary_mismatches_are_rejected(self):
        text=self.raw.decode().splitlines()
        self.raw=("\n".join([text[0]+",circuit"]+[x+",other" for x in text[1:]])+"\n").encode()
        self.spec["columns"]["energy_boundary"]="circuit"
        with self.assertRaisesRegex(case.CaseError,"경계"):
            self.run_case()

    def test_failed_cli_replaces_stale_success_report_with_input_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp); raw=tmp/"data.csv"; out=tmp/"result.json"
            raw.write_bytes(self.raw)
            args=[sys.executable,str(SCRIPT),"--spec",str(ROOT/"assets/neutral-case.json"),"--csv",str(raw),"--out",str(out)]
            subprocess.run(args,check=True)
            self.assertIn("metrics",json.loads(out.read_text()))
            raw.write_bytes(self.raw+self.raw.splitlines(keepends=True)[-1])
            p=subprocess.run(args,capture_output=True)
            self.assertEqual(p.returncode,2)
            r=json.loads(out.read_text())
            self.assertIn("input_errors",r)
            self.assertNotIn("metrics",r)


if __name__ == "__main__":
    unittest.main(verbosity=2)
