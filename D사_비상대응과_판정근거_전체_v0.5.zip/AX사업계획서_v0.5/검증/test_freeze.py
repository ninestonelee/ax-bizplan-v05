"""Acceptance tests for revision order, traceability and linked value correction."""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

scripts = Path(__file__).resolve().parents[1] / "ax-bizplan-coach-v05/scripts"
module = importlib.util.spec_from_file_location("materialize", scripts / "materialize.py")
materialize = importlib.util.module_from_spec(module)
module.loader.exec_module(materialize)

class FreezeTest(unittest.TestCase):
    def test_two_sections_use_one_decision(self):
        template="## 설계\n목표 {{energy.goal}}\n\n## 인수\n목표 {{energy.goal}}"
        data={"energy.goal":{"value":"8", "status":"후보 목표", "source":"요구서 A 2절", "scope":"도장실 kWh/ea","period":"시운전","owner":"설비 반장"}}
        result=materialize.render(template,data)
        self.assertTrue(result.startswith("## 설계\n목표 8\n\n## 인수\n목표 8"))
        self.assertIn("요구서 A 2절", result)
        data["energy.goal"]["value"]="7"
        result=materialize.render(template,data,False)
        self.assertEqual(result.count("목표 7"),2)
        data["energy.goal"]["status"]="충돌"
        with self.assertRaises(ValueError): materialize.render(template,data)
        with self.assertRaises(ValueError): materialize.render("{{not.assigned}}",data)

    def test_empty_provenance_rejected_but_zero_retained(self):
        item = dict(value=0, status="실측", source="검사 A 1행", scope="개", period="당월", owner="품질")
        self.assertEqual(materialize.render("{{count}}", {"count":item}, False), "0")
        for missing in (None, "", " "):
            with self.subTest(missing=missing), self.assertRaises(ValueError):
                materialize.render("{{count}}", {"count":dict(item, source=missing)})

    def test_cannot_skip_review_or_rewrite_frozen_copy(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp); f=out/"input.txt";f.write_text("합성");p=out/"prompt.txt";p.write_text("실행 요청")
            def cli(*args):
                return subprocess.run([sys.executable,str(scripts/"runlog.py"),args[0],str(out),*map(str,args[1:])],capture_output=True,text=True)
            self.assertEqual(cli("init","--inputs",f,"--model","test","--prompt",p,"--depth","simple","--purpose","education").returncode,0)
            self.assertNotEqual(cli("add","review1",f).returncode,0)
            for stage in ("draft1","review1","draft2","final"):self.assertEqual(cli("add",stage,f).returncode,0)
            self.assertIn("complete",cli("verify").stdout)
            self.assertNotEqual(cli("add","final",f).returncode,0)
            (out/"audit/02_review1/input.txt").write_text("사후 편집")
            self.assertNotEqual(cli("verify").returncode,0)

if __name__ == "__main__":
    unittest.main()
