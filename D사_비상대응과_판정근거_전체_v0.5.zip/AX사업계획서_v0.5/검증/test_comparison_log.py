"""근거 비교 회차의 입력 격리·스냅숏 순서와 재검증 회귀 검사."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "ax-bizplan-coach-v05/scripts/runlog.py"


class ComparisonLogTest(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.out = self.root / "회차"
        self.prompt = self.root / "prompt.txt"
        self.prompt.write_text("이번 회차에는 등록한 두 생산 자료만 사용한다.")
        self.sources = []
        for source_id in ("원천A", "원천B"):
            directory = self.root / source_id
            directory.mkdir()
            path = directory / "같은이름.txt"
            path.write_text(source_id)
            self.sources.append(path)

    def cli(self, command, *args):
        return subprocess.run(
            [sys.executable, str(SCRIPT), command, str(self.out), *map(str, args)],
            text=True, capture_output=True
        )

    def init(self, *ids):
        return self.cli("init", "--prompt", self.prompt, "--model", "시험",
                        "--depth", "comparison", "--purpose", "submission",
                        "--inputs", *self.sources, "--input-ids", *ids)

    def artifact(self, filename, value):
        path = self.root / filename
        path.write_text(value)
        return path

    def test_order_allowlist_and_frozen_files(self):
        self.assertEqual(self.init("원천A", "원천B").returncode, 0)
        audit = self.out / "audit"
        initial = json.loads((audit / "00_init/record.json").read_text())
        expected = {source.parent.name: hashlib.sha256(source.read_bytes()).hexdigest()
                    for source in self.sources}
        self.assertEqual({item["id"]: item["sha256"] for item in initial["allowed_inputs"]}, expected)
        self.assertTrue(all((audit / "00_init" / item["file"]).is_file()
                            for item in initial["allowed_inputs"]))
        self.assertEqual(initial["skill_version"], "0.5")
        checks = self.artifact("checks.json", '{"units": 2, "scanned": 2}')
        decisions = self.artifact("decisions.csv", "결정ID,판정\n한계,보류\n")
        draft = self.artifact("draft.md", "# 편성 초안\n실측 대기")
        review = self.artifact("review.md", "근거와 제안 분리 필요")
        self.assertNotEqual(self.cli("add", "draft", draft, decisions).returncode, 0)
        self.assertEqual(self.cli("add", "calculations", checks).returncode, 0)
        self.assertNotEqual(self.cli("add", "draft", draft).returncode, 0)
        self.assertEqual(self.cli("add", "draft", draft, decisions).returncode, 0)
        self.assertEqual(self.cli("add", "review", review).returncode, 0)
        final = self.artifact("final.md", "# 편성 최종안\n근거와 제안 분리")
        # 형식 검사는 Word 회귀 검사에서 수행하며 이 테스트는 파일 동결만 확인한다.
        word = self.artifact("final.docx", "워드 스냅숏 시험")
        self.assertEqual(self.cli("add", "final", final, word).returncode, 0)
        self.assertIn("complete", self.cli("verify").stdout)
        checks.write_text("작업 사본 변경")
        self.assertEqual(self.cli("verify").returncode, 0)
        (audit / "00_init/extra.txt").write_text("허용하지 않은 추가 파일")
        self.assertNotEqual(self.cli("verify").returncode, 0)
        (audit / "00_init/extra.txt").unlink()
        (audit / "02_draft/decisions.csv").write_text("사후 변경")
        self.assertNotEqual(self.cli("verify").returncode, 0)

    def test_duplicate_or_unmapped_input_ids_rejected(self):
        self.assertNotEqual(self.init("동일", "동일").returncode, 0)
        self.assertNotEqual(self.init("유일").returncode, 0)
        self.assertNotEqual(self.init("../탈출", "유일").returncode, 0)
        self.assertFalse((self.out / "audit/00_init").exists())


if __name__ == "__main__":
    unittest.main()
