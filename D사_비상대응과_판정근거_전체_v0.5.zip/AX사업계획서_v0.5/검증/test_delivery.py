"""Behavioral tests for portable field replay and procurement schedule impact."""
from copy import deepcopy
import csv
import importlib.util
from pathlib import Path
import tempfile
import unittest

skill = Path(__file__).resolve().parents[1] / "ax-bizplan-coach-v05"
spec = importlib.util.spec_from_file_location("check_delivery", skill / "scripts/check_delivery.py")
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)


def at(t):
    return f"2020-01-01T{t}:00+00:00"


def fixture():
    return {
        "lots": [
            {"lot": "A", "equipment": "X", "start": at("07:00"), "end": at("08:00")},
            {"lot": "B", "equipment": "X", "start": at("08:00"), "end": at("09:00")},
        ],
        "readings": [{"equipment": "X", "at": at(t), "kwh": k}
                     for t, k in [("07:00", 100), ("08:00", 104), ("09:00", 107)]],
        "counts": [
            {"id": "A-close", "revision": 1, "lot": "A", "qty": 40, "approved": True},
            {"id": "B-close", "revision": 1, "lot": "B", "qty": 30, "approved": True},
            {"id": "B-close", "revision": 2, "lot": "B", "qty": 28, "approved": True},
        ],
        "production_events": [{"id": "e", "equipment": "X", "at": at("08:00")}],
    }


class TestReplay(unittest.TestCase):
    def test_duplicate_reorder_boundary_and_correction(self):
        original = fixture()
        delivered = deepcopy(original)
        delivered["counts"] += delivered["counts"][:2]
        delivered["counts"].reverse()
        delivered["readings"] += delivered["readings"][1:2]
        output = tool.replay(delivered)
        self.assertEqual(tool.replay(original), output)
        self.assertEqual(output["assigned_events"], {"e": "B"})
        self.assertEqual(output["totals"], {"qty": 68, "kwh": 7})
        self.assertFalse(output["issues"])

    def test_reset_within_window_undetectable_by_endpoint_subtraction(self):
        data = fixture()
        data["readings"].extend({"equipment": "X", "at": at(t), "kwh": k}
                                for t, k in [("07:20", 109), ("07:30", 2)])
        output = tool.replay(data)
        self.assertIsNone(output["lots"]["A"]["kwh"])
        self.assertIsNone(output["totals"]["kwh"])
        self.assertEqual(output["lots"]["B"]["kwh"], 3)

    def test_unknown_energy_is_not_zero(self):
        data = fixture()
        data["readings"].pop(1)
        output = tool.replay(data)
        self.assertEqual(len(output["issues"]), 2)
        self.assertIsNone(output["totals"]["kwh"])

    def test_unapproved_correction_does_not_change_approved_count(self):
        data = fixture()
        data["counts"][2]["approved"] = False
        output = tool.replay(data)
        self.assertEqual(output["totals"]["qty"], 70)
        self.assertTrue(output["issues"])

    def test_conflicting_revision_is_not_guessed(self):
        data = fixture()
        data["counts"].append(dict(data["counts"][0], qty=41))
        with self.assertRaises(ValueError):
            tool.replay(data)

    def test_overlapping_station_assignment_rejected(self):
        data = fixture()
        data["lots"][1]["start"] = at("07:59")
        with self.assertRaises(ValueError):
            tool.replay(data)


class TestSchedule(unittest.TestCase):
    def test_procurement_delay_and_parallel_slack(self):
        tasks = [{"id": k, "duration": days, "after": after}
                 for k, days, after in [("supply", 2, []), ("prepare", 6, []),
                                         ("mount", 1, ["supply"]), ("accept", 1, ["mount", "prepare"])]]
        result = tool.delay({"tasks": tasks, "delay": {"supply": 2}})
        self.assertEqual(result["tasks"]["mount"]["shift"], 2)
        self.assertEqual(result["tasks"]["accept"]["shift"], 0)
        self.assertEqual(result["project_shift"], 0)
        with tempfile.TemporaryDirectory() as temp:
            source = skill / "assets/submission/delivery-links.csv"
            dest = Path(temp) / "links.csv"
            with source.open(encoding="utf-8-sig", newline="") as f:
                fields = next(csv.reader(f))
            with dest.open("w", encoding="utf-8-sig", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fields)
                writer.writeheader()
                writer.writerow({"작업ID": "mount", "기능ID": "read", "시험ID": "t1"})
            self.assertEqual(tool.linked_deliverables(result, dest),
                             {"mount": [{"function": "read", "test": "t1"}]})
        self.assertEqual(tool.delay({"tasks": tasks, "delay": {"supply": 5}})["project_shift"], 2)

    def test_cyclic_or_dangling_tasks_rejected(self):
        for dep in ("self", "absent"):
            with self.assertRaises(ValueError):
                tool.delay({"tasks": [{"id": "self", "duration": 1, "after": [dep]}], "delay": {}})


if __name__ == "__main__":
    unittest.main()
