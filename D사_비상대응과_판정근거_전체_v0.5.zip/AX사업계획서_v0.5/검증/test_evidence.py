"""Regression tests for the public evidence-gate CLI. Every fixture is generated in a temporary case."""

import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "ax-bizplan-coach-v05/scripts/check_evidence.py"
MANIFEST = "evidence_id kind path sha256 locator issuer required_for".split()
CLAIMS = "claim_id decision status scope statement required_evidence_ids evidence_ids approver".split()


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.actual = self.source("R1", "actual", "1차 검수기록\n대표 한겨울이 장비 인수를 승인했다.\n봄공장은 펌프를 소유한다.\n")
        self.synthetic = self.source("S1", "synthetic", "교육용 합성 입력\n모의 위원 한여름이 장비 인수를 승인했다.\n")
        self.missing = dict(evidence_id="M1", kind="missing", path="", sha256="", locator="", issuer="현장 담당")
        self.claim = dict(claim_id="C1", decision="승인", status="confirmed", scope="actual",
                          statement="대표 한겨울이 장비 인수를 승인했다.", required_evidence_ids="R1",
                          evidence_ids="R1", approver="한겨울")

    def source(self, key, kind, text):
        path = self.root / (key + ".txt")
        path.write_text(text, encoding="utf-8")
        return dict(evidence_id=key, kind=kind, path=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                    locator="line:2", issuer="기록담당")

    def write(self, filename, fields, rows):
        with (self.root / filename).open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fields)
            writer.writeheader()
            writer.writerows(rows)

    def run_gate(self, sources=None, claims=None, *, names=("manifest.csv", "claims.csv"), success=True):
        self.write(names[0], MANIFEST, [self.actual, self.synthetic, self.missing] if sources is None else sources)
        self.write(names[1], CLAIMS, [self.claim] if claims is None else claims)
        command = [sys.executable, str(SCRIPT), str(self.root)]
        if names != ("manifest.csv", "claims.csv"):
            command += ["--manifest", names[0], "--claims", names[1]]
        proc = subprocess.run(command, capture_output=True, text=True)
        result = json.loads(proc.stdout)
        self.assertEqual(proc.returncode, 0 if success else 1, result)
        self.assertEqual(result["valid"], success, result)
        return result

    def test_short_direct_quote_and_named_approver(self):
        result = self.run_gate(names=("자료.csv", "판단.csv"))
        self.assertEqual((result["sources"], result["confirmed"], result["hold"]), (3, 1, 0))

    def test_bad_hash_and_bom_bytes(self):
        self.actual["sha256"] = "0" * 64
        self.assertIn("SHA-256", self.run_gate(success=False)["error"])

    def test_location_and_ambiguous_fragment(self):
        for place in ("", "page:1", "line:0", "lines:3-2", "line:99", "text:미존재", "text:다."):
            with self.subTest(place=place):
                self.actual["locator"] = place
                self.run_gate(success=False)
        self.actual["locator"] = "text:대표 한겨울이 장비 인수를 승인했다."
        self.run_gate()

    def test_missing_cannot_pretend_a_file(self):
        self.missing["locator"] = "미제출-1p"
        self.assertIn("미수령", self.run_gate(success=False)["error"])

    def test_simulation_label_inside_source(self):
        self.synthetic["kind"] = "actual"
        self.synthetic["locator"] = "line:2"
        self.assertIn("합성 표시", self.run_gate(success=False)["error"])

    def test_same_bytes_cannot_have_two_grades(self):
        twin = dict(self.actual, evidence_id="S2", kind="synthetic", path="복사본.txt")
        (self.root / twin["path"]).write_bytes((self.root / self.actual["path"]).read_bytes())
        self.assertIn("구분 충돌", self.run_gate(sources=[self.actual, twin], success=False)["error"])

    def test_synthetic_as_actual_without_approval_language(self):
        self.claim.update(decision="계산", statement="10개 중 2개를 반품했다.", evidence_ids="S1", required_evidence_ids="S1")
        self.run_gate(success=False)
        self.claim["scope"] = "simulation"
        self.run_gate()

    def test_mixed_or_missing_inputs_block_confirmation(self):
        for required, cited in [("R1|M1", "R1"), ("R1|M1", "R1|M1"), ("R1", "R1|S1"), ("", "R1")]:
            with self.subTest(required=required, cited=cited):
                self.claim.update(required_evidence_ids=required, evidence_ids=cited)
                self.run_gate(success=False)

    def test_valid_hold_lists_open_dependencies(self):
        self.claim.update(status="hold", required_evidence_ids="R1|M1|S1", evidence_ids="R1|S1",
                          statement="도장 원본 미수령으로 견적 승인을 보류한다.", approver="")
        result = self.run_gate()
        self.assertEqual(result["held"], [dict(claim_id="C1", reason=self.claim["statement"], pending_evidence_ids=["M1", "S1"])])
        self.assertEqual((result["confirmed"], result["hold"]), (0, 1))

    def test_hold_may_have_zero_citations(self):
        self.claim.update(status="hold", decision="ownership", required_evidence_ids="M1", evidence_ids="",
                          statement="장비 대장의 소유자 확인 필요.", approver="")
        self.run_gate()

    def test_hold_with_all_sources_but_unresolved_judgment(self):
        self.claim.update(status="hold", decision="심의", statement="인용 원본의 서로 다른 모델번호에 대해 대조 요청.")
        self.assertEqual(self.run_gate()["held"][0]["pending_evidence_ids"], [])

    def test_unknown_and_duplicate_references(self):
        for name in ("required_evidence_ids", "evidence_ids"):
            for referenced in ("NOPE", "R1|R1", "R1|"):
                with self.subTest(name=name, referenced=referenced):
                    self.run_gate(claims=[dict(self.claim, **{name: referenced})], success=False)

    def test_duplicate_register_ids(self):
        self.run_gate(sources=[self.actual, self.actual], success=False)
        self.run_gate(claims=[self.claim, self.claim], success=False)
        self.run_gate(claims=[dict(self.claim, claim_id="R1")], success=False)

    def test_preregistered_requirements_cannot_be_dropped_from_both_lists(self):
        self.missing["required_for"] = "C1"
        self.assertIn("지정한 필수 입력", self.run_gate(success=False)["error"])

    def test_approval_actor_and_actual_source(self):
        for name in ("", "한여름"):
            self.run_gate(claims=[dict(self.claim, approver=name)], success=False)
        self.claim.update(required_evidence_ids="S1", evidence_ids="S1", scope="simulation",
                          decision="approval", approver="한여름", statement="모의 위원 한여름이 장비 인수를 승인했다.")
        self.run_gate()
        self.claim["statement"] = "위원 한여름이 장비 인수를 승인했다."
        self.run_gate(success=False)

    def test_application_form_is_not_an_approval(self):
        self.actual = self.source("R1", "actual", "접수함\n한겨울의 승인 요청서\n")
        self.claim.update(decision="approval", statement="한겨울의 승인 요청서")
        self.run_gate(success=False)
        self.actual = self.source("R1", "actual", "접수함\n한겨울 승인란\n")
        self.claim["statement"] = "한겨울 승인란"
        self.run_gate(success=False)

    def test_no_unqualified_live_assertion_inside_hold_or_simulation(self):
        self.run_gate(claims=[dict(self.claim, status="hold", statement="대표 한겨울이 장비 인수를 승인했다. 견적은 보류한다.")], success=False)
        self.claim.update(scope="simulation", required_evidence_ids="S1", evidence_ids="S1", decision="비고")
        for phrase in ("실제 양사가 회의에 참석했다.", "실제 공급사 등록 완료.", "실제 장비를 소유한다.", "실제 현장에서 230개를 생산했다."):
            with self.subTest(phrase=phrase):
                self.run_gate(claims=[dict(self.claim, statement=phrase)], success=False)

    def test_party_asset_and_attendance_cannot_be_substituted(self):
        self.actual["locator"] = "lines:1-3"
        self.claim.update(decision="기타", statement="봄공장은 펌프를 소유한다.", approver="")
        self.run_gate()
        for phrase in ("봄공장은 터빈을 소유한다.", "새공장은 펌프를 소유한다.", "양사 대표가 참석했다.",
                       "주식회사 새봄은 등록 공급사로 확정되었다.", "김겨울을 책임자로 배치했다.", "견적서 확정"):
            with self.subTest(phrase=phrase):
                self.run_gate(claims=[dict(self.claim, statement=phrase)], success=False)

    def test_substring_cannot_hide_negation(self):
        self.actual = self.source("R1", "actual", "접수함\n대표 한겨울이 장비 인수를 승인했다는 주장은 사실이 아니다.\n")
        for place in ("line:2", "text:대표 한겨울이 장비 인수를 승인했다"):
            with self.subTest(place=place):
                self.actual["locator"] = place
                self.run_gate(success=False)

    def test_paths_cannot_escape_case_even_via_symlink(self):
        with tempfile.TemporaryDirectory() as other:
            external = Path(other) / "external.txt"
            external.write_text("회의\n참석\n", encoding="utf-8")
            (self.root / "link.txt").symlink_to(external)
            self.actual["path"] = "link.txt"
            self.assertIn("사례 내부 파일", self.run_gate(success=False)["error"])


if __name__ == "__main__":
    unittest.main()
