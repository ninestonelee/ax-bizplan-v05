"""모의 편철표 파일·양사 유효 권한과 회신 대상을 날짜순으로 대조한다."""
import argparse
import hashlib
import json
from pathlib import Path


def checksum(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def md_rows(text):
    tables = {}
    group = None
    for line in text.splitlines():
        if line.startswith('## '):
            group = line[3:].strip()
            tables[group] = []
        if group and line.startswith('|') and line.endswith('|'):
            values = [x.strip() for x in line[1:-1].split('|')]
            if not all(set(x) <= {'-', ':'} for x in values):
                tables[group].append(values)
    return tables


def match(root):
    root = root.resolve()
    bundle_file = next(root.glob('E23*편철*.json'))
    bundle = json.loads(bundle_file.read_text())
    digest = checksum(bundle_file)
    targets = set()
    for doc in bundle['documents']:
        p=(root/doc['file']).resolve()
        if p.parent != root or p.name in targets or checksum(p)!=doc['sha256']:
            raise ValueError(f"편철 불일치 {doc['file']}")
        targets.add(p.name)
    if not any(x.startswith('E23') and x.endswith('.md') for x in targets):
        raise ValueError('심의 본문 누락')
    tables=md_rows(next(root.glob('E23*회신*.md')).read_text())
    def table(name):
        head,*body=tables[name]
        return [dict(zip(head,row,strict=True)) for row in body]
    mandates={v['주체']:v for v in table('권한 등록')}
    live={}
    states=[]
    for row in sorted(table('회신 이력'),key=lambda r:r['시각']):
        role=mandates.get(row['주체'])
        authorized=bool(role and role['회사']==row['회사'] and role['첫날']<=row['시각'][:10]<=role['마지막날'] and role['권한']=='신청안 최종동의')
        valid=authorized and row['응답']=='동의' and row['대상판']==bundle['revision'] and row['편철SHA256']==digest
        if authorized and row['대상판']==bundle['revision']:
            live[row['회사']]=valid
        states.append({'회신':row['접수'],'주체유효':authorized,'판과첨부일치':valid,'양측모의동의':all(live.get(k,False) for k in ['도입','공급'])})
    return {'편철SHA256':digest,'표적판':bundle['revision'],'대상파일':len(targets),'회신순서':states}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('원자료',type=Path)
    args=parser.parse_args();print(json.dumps(match(args.원자료),ensure_ascii=False,indent=2))
