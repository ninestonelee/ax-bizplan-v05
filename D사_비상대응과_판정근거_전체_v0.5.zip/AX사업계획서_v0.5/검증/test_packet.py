"""교육용 심의 문서에 실제로 제공한 수정 전·후 응답을 재현한다."""
import importlib.util
import shutil
import tempfile
import unittest
from pathlib import Path

QA = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('packet', QA/'심의판_대조.py')
PACKET = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PACKET)


class PacketTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)/'sources'
        shutil.copytree(QA.parent/'D사/B/sources', self.root)
        self.replies = next(self.root.glob('E23*회신*.md'))

    def states(self):
        return [r['양측모의동의'] for r in PACKET.match(self.root)['회신순서']]

    def test_only_corrected_bundle_completes_both_sides(self):
        self.assertEqual(self.states(), [False,False,True])

    def test_no_corrected_reply(self):
        lines=self.replies.read_text().splitlines(keepends=True)
        self.replies.write_text(''.join(x for x in lines if not x.startswith('| R-F3 |')))
        self.assertEqual(self.states(), [False,False])

    def test_expired_delegation(self):
        text=self.replies.read_text().replace('SP-DEC | SY01-05-01 | SY01-06-30','SP-DEC | SY01-05-01 | SY01-05-17')
        self.replies.write_text(text)
        self.assertEqual(self.states(), [False,False,False])

    def test_attachment_drift(self):
        f=next(self.root.glob('E21*'))
        f.write_bytes(f.read_bytes()+b'\n')
        with self.assertRaisesRegex(ValueError,'편철 불일치'):
            PACKET.match(self.root)


if __name__=='__main__':
    unittest.main()
