import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


TOOL = Path(__file__).resolve().parents[1] / 'ax-bizplan-coach-v05/scripts/check_metric_scope.py'
FIELDS = 'period name value kind file period_column value_column quote rule'.split()


class MetricScopeTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p = Path(self.tmp.name)
        (self.p/'거래.csv').write_text('기간,유통문의_건\nY-2,35\nY-1,40\n')
        (self.p/'기록.md').write_text('Y-1 유효 문의는 40건이다. Y0 계획은 유효 문의 48건이다. 같은 품목은 30일 이내 묶는다.')
        self.raw = ['Y-2','유통문의','35','raw','거래.csv','기간','유통문의_건','','']
        self.observed = ['Y-1','유효문의','40','defined','기록.md','','','Y-1 유효 문의는 40건이다.','같은 품목은 30일 이내 묶는다.']

    def run_rows(self, rows):
        register = self.p/'대장.csv'
        with register.open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f);w.writerow(FIELDS);w.writerows(rows)
        run=subprocess.run([sys.executable,'-B',str(TOOL),str(self.p),str(register)],capture_output=True,text=True)
        return run.returncode, json.loads(run.stdout)

    def test_periods_sources_and_kinds(self):
        target = self.observed.copy()
        target[0],target[2],target[3],target[7]='Y0','48','target','Y0 계획은 유효 문의 48건이다.'
        code,data = self.run_rows([self.raw,self.observed,target])
        self.assertEqual((code,data['rows'],data['valid']),(0,3,True))

    def test_raw_column_cannot_be_renamed(self):
        self.raw[1]='유효 문의'
        self.assertEqual(self.run_rows([self.raw])[0],1)

    def test_recent_definition_cannot_be_backdated(self):
        self.observed[0]='Y-2'
        self.assertEqual(self.run_rows([self.observed])[0],1)

    def test_borrowed_value_from_another_sentence(self):
        self.observed[2],self.observed[7]='48','Y-1 유효 문의는 40건이다. Y0 계획은 유효 문의 48건이다.'
        self.assertEqual(self.run_rows([self.observed])[0],1)

    def test_ambiguous_raw_period_and_missing_rule(self):
        with (self.p/'거래.csv').open('a') as f:f.write('Y-2,35\n')
        self.observed[8]='미수령 규정 문장'
        code,data=self.run_rows([self.raw,self.observed])
        self.assertEqual((code,len(data['errors'])),(1,2))
